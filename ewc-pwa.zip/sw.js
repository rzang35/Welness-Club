/* Service worker — Executive Wellness Club
   Changez VERSION à chaque mise en ligne pour forcer la mise à jour. */
const VERSION = 'ewc-v1';
const SHELL = [
  './', './index.html', './scanner.html', './manifest.webmanifest',
  './icons/icon-192.png', './icons/icon-512.png', './icons/apple-touch-icon.png',
  './coach.html', './programmes.html', './programmesportif.html', './recettes.html',
  './routine-beaute.html', './soinsesthetiques.html', './peptides.html'
];

self.addEventListener('install', e => {
  e.waitUntil((async () => {
    const cache = await caches.open(VERSION);
    // Fichier par fichier : une page absente ne bloque pas l'installation.
    await Promise.all(SHELL.map(u => cache.add(u).catch(() => {})));
    self.skipWaiting();
  })());
});

self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Données nutritionnelles : toujours en direct (jamais de valeurs périmées).
  if (url.hostname.endsWith('openfoodfacts.org')) return;

  // Pages : réseau d'abord, cache si hors ligne.
  if (req.mode === 'navigate') {
    e.respondWith((async () => {
      try {
        const res = await fetch(req);
        const cache = await caches.open(VERSION);
        cache.put(req, res.clone());
        return res;
      } catch {
        return (await caches.match(req, { ignoreSearch: true })) || caches.match('./index.html');
      }
    })());
    return;
  }

  // Polices, icônes, scripts : cache d'abord, mise à jour en arrière-plan.
  const cacheable = url.origin === location.origin ||
    /fonts\.(googleapis|gstatic)\.com|cdn\.jsdelivr\.net/.test(url.hostname);
  if (!cacheable) return;
  e.respondWith((async () => {
    const cache = await caches.open(VERSION);
    const hit = await cache.match(req);
    const net = fetch(req).then(res => {
      if (res && (res.ok || res.type === 'opaque')) cache.put(req, res.clone());
      return res;
    }).catch(() => hit);
    return hit || net;
  })());
});
