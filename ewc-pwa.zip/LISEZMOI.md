# Executive Wellness Club : version application (PWA)

## Contenu
- `index.html` : votre page d'accueil, avec le lien vers le manifeste, l'enregistrement du service worker et le lien « Scanner nutritionnel » dans le menu Outils.
- `scanner.html` : le scanner de code-barres (calories et macronutriments via Open Food Facts) et le journal du jour.
- `manifest.webmanifest` : nom, couleurs et icônes de l'application.
- `sw.js` : service worker (installation, fonctionnement hors ligne des pages déjà visitées).
- `icons/` : icônes de l'application.
- `vendor/zxing.min.js` : lecteur de code-barres pour iPhone et navigateurs sans lecteur intégré.

## Mise en ligne
1. Déposez tous ces fichiers à la racine du site, à côté de coach.html, programmes.html, etc.
2. Le site doit être servi en HTTPS (obligatoire pour la caméra et l'installation).
3. Dans le `<head>` de chacune des autres pages, ajoutez :

```html
<link rel="manifest" href="manifest.webmanifest">
<link rel="apple-touch-icon" href="icons/apple-touch-icon.png">
<meta name="theme-color" content="#060C17">
```

et juste avant `</body>` :

```html
<script>
  if ('serviceWorker' in navigator) navigator.serviceWorker.register('sw.js').catch(() => {});
</script>
```

4. À chaque mise à jour du site, changez `VERSION` en haut de `sw.js` (ewc-v1 → ewc-v2) pour que les téléphones récupèrent la nouvelle version.

## Vérifier
Chrome sur ordinateur : clic droit > Inspecter > onglet Application > Manifest. Les erreurs éventuelles s'y affichent.
